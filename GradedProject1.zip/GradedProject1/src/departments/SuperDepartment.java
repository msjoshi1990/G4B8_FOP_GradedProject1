package departments;

abstract public class SuperDepartment 
{
	abstract public String departmentName();	
	abstract public String getTodaysWork();
    abstract public String getWorkDeadline();
	abstract public String isTodayAHoliday();
}